#include "nbtool_config.h"
#include "/root/minix/tools/compat/../../include/netconfig.h"
