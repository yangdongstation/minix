#include "nbtool_config.h"
#include "/root/minix/tools/compat/../../include/rpc/types.h"
