/* Generated automatically. */
static const char configuration_arguments[] = "/root/minix/tools/gcc/../../external/gpl3/gcc/dist/configure --target=riscv64-elf32-minix --enable-long-long --enable-threads --with-bugurl=http://www.NetBSD.org/Misc/send-pr.html --with-pkgversion='NetBSD nb2 20150115' --with-system-zlib --enable-__cxa_atexit --disable-libssp --enable-visibility --disable-threads --disable-tls --with-sysroot=/root/minix/obj/destdir.evbriscv64 --with-mpc=/root/minix/obj/tooldir.Linux-6.12.57+deb13-amd64-x86_64 --with-mpfr=/root/minix/obj/tooldir.Linux-6.12.57+deb13-amd64-x86_64 --with-gmp=/root/minix/obj/tooldir.Linux-6.12.57+deb13-amd64-x86_64 --disable-nls --disable-multilib --program-transform-name='s,^,riscv64-elf32-minix-,' --enable-languages='c c++ objc' --prefix=/root/minix/obj/tooldir.Linux-6.12.57+deb13-amd64-x86_64 --disable-shared";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
